# Golpes API

## Requisitos
- Java 17+
- Maven
- Docker (opcional)
- MySQL (opcional se não usar Docker)

## Rodando localmente
1. Configure `application.properties` com seu MySQL.
2. `mvn clean package`
3. `java -jar target/golpes-api-0.0.1-SNAPSHOT.jar`
4. A API ficará disponível em `http://localhost:8080/api/golpes`

## Rodando com Docker
1. `mvn clean package`
2. `docker-compose up --build`
