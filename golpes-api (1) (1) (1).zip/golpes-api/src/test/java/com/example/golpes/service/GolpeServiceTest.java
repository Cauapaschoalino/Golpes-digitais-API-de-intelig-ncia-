package com.example.golpes.service;

import com.example.golpes.dto.GolpeDTO;
import com.example.golpes.model.Golpe;
import com.example.golpes.repository.GolpeRepository;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;

import java.time.LocalDate;
import java.util.Optional;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.Mockito.*;

@ExtendWith(MockitoExtension.class)
class GolpeServiceTest {

    @Mock
    private GolpeRepository repository;

    @InjectMocks
    private GolpeService service;

    @Test
    void create_shouldSaveAndReturnDTO() {
        // Arrange
        GolpeDTO inputDto = GolpeDTO.builder()
                .tipo("PIX")
                .dataOcorrencia(LocalDate.now())
                .build();

        Golpe savedGolpe = Golpe.builder()
                .id(1L)
                .tipo("PIX")
                .dataOcorrencia(LocalDate.now())
                .build();

        when(repository.save(any(Golpe.class))).thenReturn(savedGolpe);

        // Act
        GolpeDTO created = service.create(inputDto);

        // Assert
        verify(repository, times(1)).save(any(Golpe.class));
        assertNotNull(created.getId());
        assertEquals("PIX", created.getTipo());
    }

    @Test
    void findById_shouldReturnDTOWhenFound() {
        // Arrange
        Long id = 1L;
        Golpe foundGolpe = Golpe.builder()
                .id(id)
                .tipo("Phishing")
                .dataOcorrencia(LocalDate.now())
                .build();

        when(repository.findById(id)).thenReturn(Optional.of(foundGolpe));

        // Act
        GolpeDTO result = service.findById(id);

        // Assert
        assertNotNull(result);
        assertEquals(id, result.getId());
        assertEquals("Phishing", result.getTipo());
    }
}
