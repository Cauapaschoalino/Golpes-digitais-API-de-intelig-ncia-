package com.example.golpes;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class GolpesApiApplication {
    public static void main(String[] args) {
        SpringApplication.run(GolpesApiApplication.class, args);
    }
}
