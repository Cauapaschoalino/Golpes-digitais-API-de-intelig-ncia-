package com.example.golpes.controller;

import com.example.golpes.dto.GolpeDTO;
import com.example.golpes.exception.ResourceNotFoundException;
import com.example.golpes.service.GolpeService;
import jakarta.validation.Valid;
import lombok.RequiredArgsConstructor;
import org.springframework.http.*;
import org.springframework.web.bind.annotation.*;

import java.util.List;
import java.util.Map;

@RestController
@RequestMapping("/api/golpes")
@RequiredArgsConstructor
public class GolpeController {

    private final GolpeService service;

    @PostMapping
    public ResponseEntity<GolpeDTO> create(@Valid @RequestBody GolpeDTO dto) {
        GolpeDTO created = service.create(dto);
        return ResponseEntity.status(HttpStatus.CREATED).body(created);
    }

    @GetMapping
    public ResponseEntity<List<GolpeDTO>> findAll(@RequestParam(required = false) String tipo) {
        if (tipo != null && !tipo.isEmpty()) {
            return ResponseEntity.ok(service.searchByTipo(tipo));
        }
        return ResponseEntity.ok(service.findAll());
    }

    @GetMapping("/{id}")
    public ResponseEntity<GolpeDTO> findById(@PathVariable Long id) {
        try {
            return ResponseEntity.ok(service.findById(id));
        } catch (ResourceNotFoundException e) {
            return ResponseEntity.notFound().build();
        }
    }

    @PutMapping("/{id}")
    public ResponseEntity<GolpeDTO> update(@PathVariable Long id, @Valid @RequestBody GolpeDTO dto) {
        try {
            return ResponseEntity.ok(service.update(id, dto));
        } catch (ResourceNotFoundException e) {
            return ResponseEntity.notFound().build();
        }
    }

    @DeleteMapping("/{id}")
    public ResponseEntity<Void> delete(@PathVariable Long id) {
        try {
            service.delete(id);
            return ResponseEntity.noContent().build();
        } catch (ResourceNotFoundException e) {
            return ResponseEntity.notFound().build();
        }
    }

    @GetMapping("/stats")
    public ResponseEntity<Map<String, Object>> getStatistics() {
        return ResponseEntity.ok(service.statistics());
    }
}
