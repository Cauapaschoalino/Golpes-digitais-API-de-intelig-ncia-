package com.example.golpes.dto;

import lombok.*;
import jakarta.validation.constraints.*;
import java.time.LocalDate;

@Data
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class GolpeDTO {

    private Long id;

    @NotBlank(message = "Tipo é obrigatório")
    private String tipo;

    private String descricao;

    @DecimalMin(value = "0.0", inclusive = false, message = "Valor deve ser positivo")
    private Double valorPerdido;

    @NotNull(message = "Data da ocorrência é obrigatória")
    private LocalDate dataOcorrencia;

    private String localidade;
}
