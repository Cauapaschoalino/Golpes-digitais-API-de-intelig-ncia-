package com.example.golpes.repository;

import com.example.golpes.model.Golpe;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import java.util.List;

@Repository
public interface GolpeRepository extends JpaRepository<Golpe, Long> {
    List<Golpe> findByTipoContainingIgnoreCase(String tipo);
}
