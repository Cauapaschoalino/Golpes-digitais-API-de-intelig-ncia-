package com.example.golpes.service;

import com.example.golpes.dto.GolpeDTO;
import com.example.golpes.exception.ResourceNotFoundException;
import com.example.golpes.model.Golpe;
import com.example.golpes.repository.GolpeRepository;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;

import java.util.*;
import java.util.stream.Collectors;

@Service
@RequiredArgsConstructor
public class GolpeService {

    private final GolpeRepository repository;

    private Golpe toEntity(GolpeDTO dto) {
        return Golpe.builder()
                .id(dto.getId())
                .tipo(dto.getTipo())
                .descricao(dto.getDescricao())
                .valorPerdido(dto.getValorPerdido())
                .dataOcorrencia(dto.getDataOcorrencia())
                .localidade(dto.getLocalidade())
                .build();
    }

    private GolpeDTO toDTO(Golpe g) {
        return GolpeDTO.builder()
                .id(g.getId())
                .tipo(g.getTipo())
                .descricao(g.getDescricao())
                .valorPerdido(g.getValorPerdido())
                .dataOcorrencia(g.getDataOcorrencia())
                .localidade(g.getLocalidade())
                .build();
    }

    public GolpeDTO create(GolpeDTO dto) {
        Golpe saved = repository.save(toEntity(dto));
        return toDTO(saved);
    }

    public List<GolpeDTO> findAll() {
        return repository.findAll().stream().map(this::toDTO).collect(Collectors.toList());
    }

    public GolpeDTO findById(Long id) {
        Golpe g = repository.findById(id).orElseThrow(() -> new ResourceNotFoundException("Golpe não encontrado: " + id));
        return toDTO(g);
    }

    public GolpeDTO update(Long id, GolpeDTO dto) {
        Golpe existing = repository.findById(id).orElseThrow(() -> new ResourceNotFoundException("Golpe não encontrado: " + id));
        existing.setTipo(dto.getTipo());
        existing.setDescricao(dto.getDescricao());
        existing.setValorPerdido(dto.getValorPerdido());
        existing.setDataOcorrencia(dto.getDataOcorrencia());
        existing.setLocalidade(dto.getLocalidade());
        return toDTO(repository.save(existing));
    }

    public void delete(Long id) {
        if (!repository.existsById(id)) throw new ResourceNotFoundException("Golpe não encontrado: " + id);
        repository.deleteById(id);
    }

    public Map<String, Object> statistics() {
        List<Golpe> all = repository.findAll();
        Map<String, Long> byType = all.stream()
                .collect(Collectors.groupingBy(Golpe::getTipo, Collectors.counting()));

        double totalPerdido = all.stream()
                .filter(g -> g.getValorPerdido() != null)
                .mapToDouble(Golpe::getValorPerdido)
                .sum();

        Map<String, Object> stats = new HashMap<>();
        stats.put("totalRegistros", all.size());
        stats.put("totalPerdido", totalPerdido);
        stats.put("porTipo", byType);
        return stats;
    }

    public List<GolpeDTO> searchByTipo(String tipo) {
        return repository.findByTipoContainingIgnoreCase(tipo).stream().map(this::toDTO).collect(Collectors.toList());
    }
}
