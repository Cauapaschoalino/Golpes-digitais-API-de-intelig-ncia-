package com.example.golpes.model;

import jakarta.persistence.*;
import lombok.*;

import java.time.LocalDate;

@Entity
@Table(name = "golpes")
@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class Golpe {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @Column(nullable = false)
    private String tipo; // ex: "PIX", "Phishing", "Clonagem WhatsApp"

    @Column(length = 2000)
    private String descricao;

    private Double valorPerdido;

    private LocalDate dataOcorrencia;

    private String localidade; // cidade/estado

}
